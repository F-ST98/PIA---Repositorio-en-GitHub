﻿#Escaneo de puertos activos en la red
#
#Elaborado por: Fernando Sosa Tovar en colaboracion con Gerardo Bernal Carranza
#Matricula: 1727912
#Fecha: 16/10/2021
#
#Menu del programa
Write-Host "ELIGA LA OPCION QUE DESEA REALIZAR."
Write-Host ""
Write-Host "1.Escaneo de toda la subred."
Write-Host "2.Escaneo de puertos para un equipo o direccion ip en particular."
Write-Host "3.Escaneo de puertos para todos los equipos que estén activos en la red."
$opcion = Read-Host
#
#
#Escaneo de toda la subred buscando IP´s activas
function Scan-Subred{
    $subred = (Get-NetRoute -DestinationPrefix 0.0.0.0/0).NextHop
    $rango = $subred.Substring(0,$subred.IndexOf('.') + 1 + $subred.Substring($subred.IndexOf('.') + 1).IndexOf('.') + 3)
    $punto = $rango.EndsWith('.')
    if ($punto -like "False" ){
        $rango = $rango + '.'
    }
    $rango_ip = @(1..254)
    foreach ($r in $rango_ip){
        $actual = $rango + $r
        Write-Host $actual
        $responde = Test-Connection $actual -Quiet -Count 1
        if ($responde -eq "True"){
            Write-Output ""
            Write-Host " Host responde: " -NoNewline; Write-Host $actual -ForegroundColor Green
        }
    }
}
#
#
#Escaneo de los puertos buscando los que esten abiertos
function Scan-Port{
    $dirip=Read-Host "Ingrese la ip a escanear"
    Write-Host "Ingrese el rango de puertos a escanear"
    $portini = Read-Host "Ingrese el puerto inicial"
    $portfin = Read-Host "Ingrese el puerto final"
    $rangoport = @($portini..$portfin)
    foreach ($p in $rangoport){
        $TCPObject = New-Object System.Net.Sockets.TcpClient
            try{$resultado = TCPObject.ConnectAsync($dirip,$p).Wait($wattime)}catch{}
            if ($resultado -eq "True"){
                Write-Host "Puerto Abierto: " -NoNewline; Write-Host $p -ForegroundColor Green
            }
    }
}
#
#
#Escaneo de los puertos abiertos de las IP´s que esten activas
function Scan-PortIP{
    Write-Host "Ingrese el rango de puertos a escanear en las IP´s activas"
    $portini = Read-Host "Ingrese el puerto inicial:"
    $portfin = Read-Host "Ingrese el puerto final:"
    $rangoport = @($portini..$portfin)

   $subred = (Get-NetRoute -DestinationPrefix 0.0.0.0/0).NextHop
    $rango = $subred.Substring(0,$subred.IndexOf('.') + 1 + $subred.Substring($subred.IndexOf('.') + 1).IndexOf('.') + 3)
    $punto = $rango.EndsWith('.')
    if ($punto -like "False" ){
        $rango = $rango + '.'
    }
    $rango_ip = @(1..254)
    foreach ($r in $rango_ip){
        $actual = $rango + $r
        Write-Host $actual
        $responde = Test-Connection $actual -Quiet -Count 1
        if ($responde -eq "True"){
            Write-Output ""
            Write-Host " Host: " -NoNewline; Write-Host $actual -ForegroundColor Green 

            foreach ($p in $rangoport){
                $TCPObject = New-Object System.Net.Sockets.TcpClient
                try{$resultado = TCPObject.ConnectAsync($actual,$p).Wait($wattime)}catch{}
                if ($resultado -eq "True"){
                    Write-Host "Puerto Abierto: " -NoNewline; Write-Host $p -ForegroundColor Green
                }
            }
        }
    }
}
#
#
#Verificando la opcion elegida en el menu y seleccionando el caso
switch ($opcion){
    1{
        Scan-Subred
        break
    }
    2{
        Scan-Port
        break
    }
    3{
        Scan-PortIP
        break
    }
    default{
        Write-Host "Valor incorrecto"
    }
}