import nmap

nscan = nmap.PortScanner()
ip = input("Ingrese la IP objetivo: ")
ini = input("Ingrese el puerto inicial: ")
fin = input("Ingrese el puerto final: ")

for i in range(int(ini), int(fin)+1, ++1):
    port = nscan.scan(str(ip),str(i))
    port = port['scan'][ip]['tcp'][i]['state']
    print(f'Puerto {i} is {port}.')
