from tkinter import *
from tkinter.ttk import *
from time import strftime

wnd = Tk()
wnd.title('Reloj-Tarea 8-1727912')


def hora():
    datos = strftime('%I:%M:%S %p')
    label.config(text=datos)
    label.after(1000, hora)


label = Label(wnd, font=('Cambria', 50), padding='40', background='black', foreground='red')
label.pack(expand=True)
hora()
mainloop()
